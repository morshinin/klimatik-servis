<?php
function ValidateEmail($email)
{
   $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
   return preg_match($pattern, $email);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form1')
{
   $mailto = 'tomaidu.yana@yandex.ru';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Website form Кондиционеры';
   $message = 'Values submitted from web site form: Кондиционеры';
   $success_url = './Sps.php';
   $error_url = './error2.php';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=UTF-8'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Ремонт | Установка кондиционеров в Ташкенте по доступным ценам</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="Kondicioner.css" rel="stylesheet" type="text/css">
<link href="zayavka.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function ValidateZayavka(theForm)
{
   var regexp;
   if (theForm.Editbox1.value == "")
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox1.focus();
      return false;
   }
   if (theForm.Editbox1.value.length < 2)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox1.focus();
      return false;
   }
   if (theForm.Editbox1.value.length > 25)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox1.focus();
      return false;
   }
   if (theForm.Editbox2.value == "")
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox2.focus();
      return false;
   }
   if (theForm.Editbox2.value.length < 7)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox2.focus();
      return false;
   }
   if (theForm.Editbox2.value.length > 14)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox2.focus();
      return false;
   }
   return true;
}
</script>
<!-- Поместите код Google Analystics сюда -->
</head>
<body>
<div id="container">
<div id="wb_Form1" style="position:absolute;left:1px;top:10px;width:310px;height:286px;z-index:5;">
<form name="Zayavka" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" accept-charset="UTF-8" id="Form1" onsubmit="return ValidateZayavka(this)">
<input type="hidden" name="formid" value="form1">
<input type="text" id="Editbox1" style="position:absolute;left:34px;top:113px;width:231px;height:34px;line-height:34px;z-index:0;" name="Name:" value="" placeholder="&#1042;&#1072;&#1096;&#1077; &#1048;&#1084;&#1103;?">
<input type="text" id="Editbox2" style="position:absolute;left:34px;top:155px;width:231px;height:33px;line-height:33px;z-index:1;" name="Telephone:" value="" placeholder="&#1042;&#1072;&#1096; &#1058;&#1077;&#1083;&#1077;&#1092;&#1086;&#1085;?">
<div id="wb_Text8" style="position:absolute;left:21px;top:264px;width:268px;height:16px;text-align:center;z-index:2;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:13px;">В&#1040;&#1064;&#1048; &#1044;&#1040;&#1053;&#1053;&#1067;&#1045; &#1053;&#1045; &#1041;&#1059;&#1044;&#1059;&#1058; &#1055;&#1045;&#1056;&#1045;&#1044;&#1040;&#1053;&#1067; &#1058;&#1056;&#1045;&#1058;&#1048;&#1052; &#1051;&#1048;&#1062;&#1040;&#1052;</span></div>
<div id="wb_Text2" style="position:absolute;left:12px;top:25px;width:287px;height:66px;text-align:center;z-index:3;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:19px;"><strong>ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНЫЙ ВЫЕЗД МАСТЕРА И ПОЛУЧИТЕ СКИДКУ ПО АКЦИИ!</strong></span></div>
<input type="submit" id="Button1" name="Knopka" value="Оставить Заявку" style="position:absolute;left:27px;top:208px;width:257px;height:47px;z-index:4;">
</form>
</div>
</div>
</body>
</html>