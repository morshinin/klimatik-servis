<?php
function ValidateEmail($email)
{
   $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
   return preg_match($pattern, $email);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form1')
{
   $mailto = 'tomaidu.yana@yandex.ru';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Website form Кондиционеры';
   $message = 'Values submitted from web site form: Кондиционеры';
   $success_url = './spasibo.php';
   $error_url = './error.php';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=UTF-8'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form2')
{
   $mailto = 'tomaidu.yana@yandex.ru';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Website form Кондиционеры';
   $message = 'Values submitted from web site form: Кондиционеры';
   $success_url = './spasibo.php';
   $error_url = './error.php';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=UTF-8'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['formid'] == 'form3')
{
   $mailto = 'tomaidu.yana@yandex.ru';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Website form Кондиционеры';
   $message = 'Values submitted from web site form: Кондиционеры';
   $success_url = './spasibo.php';
   $error_url = './error.php';
   $error = '';
   $eol = "\n";
   $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=UTF-8'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Ремонт | Установка кондиционеров в Москве по доступным ценам</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="Kondicioner.css" rel="stylesheet" type="text/css">
<link href="index.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="jquery-1.11.1.min.js"></script>
<script type="text/javascript">
function ValidateFormverh(theForm)
{
   var regexp;
   if (theForm.Editbox1.value == "")
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox1.focus();
      return false;
   }
   if (theForm.Editbox1.value.length < 2)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox1.focus();
      return false;
   }
   if (theForm.Editbox1.value.length > 25)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox1.focus();
      return false;
   }
   if (theForm.Editbox2.value == "")
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox2.focus();
      return false;
   }
   if (theForm.Editbox2.value.length < 7)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox2.focus();
      return false;
   }
   if (theForm.Editbox2.value.length > 14)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox2.focus();
      return false;
   }
   return true;
}
</script>
<script type="text/javascript">
function ValidateFormseredina(theForm)
{
   var regexp;
   if (theForm.Editbox3.value == "")
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox3.focus();
      return false;
   }
   if (theForm.Editbox3.value.length < 2)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox3.focus();
      return false;
   }
   if (theForm.Editbox3.value.length > 25)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox3.focus();
      return false;
   }
   if (theForm.Editbox4.value == "")
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox4.focus();
      return false;
   }
   if (theForm.Editbox4.value.length < 7)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox4.focus();
      return false;
   }
   if (theForm.Editbox4.value.length > 14)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox4.focus();
      return false;
   }
   return true;
}
</script>
<script type="text/javascript">
function ValidateFormniz(theForm)
{
   var regexp;
   if (theForm.Editbox5.value == "")
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox5.focus();
      return false;
   }
   if (theForm.Editbox5.value.length < 2)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox5.focus();
      return false;
   }
   if (theForm.Editbox5.value.length > 25)
   {
      alert("Введите Ваше Имя!");
      theForm.Editbox5.focus();
      return false;
   }
   if (theForm.Editbox6.value == "")
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox6.focus();
      return false;
   }
   if (theForm.Editbox6.value.length < 7)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox6.focus();
      return false;
   }
   if (theForm.Editbox6.value.length > 14)
   {
      alert("Введите Ваш телефон!");
      theForm.Editbox6.focus();
      return false;
   }
   return true;
}
</script>
<script type="text/javascript" src="fancybox/jquery.easing-1.3.pack.js"></script>
<link rel="stylesheet" href="fancybox/jquery.fancybox-1.3.0.css" type="text/css">
<script type="text/javascript" src="fancybox/jquery.fancybox-1.3.0.pack.js"></script>
<script type="text/javascript" src="fancybox/jquery.mousewheel-3.0.2.pack.js"></script>
<script type="text/javascript" src="wwb10.min.js"></script>
<!-- Поместите код Google Analystics сюда -->
</head>
<body>
<div id="container">
<div id="wb_Image4" style="position:absolute;left:7px;top:3791px;width:954px;height:553px;z-index:40;">
<img src="images/FDDF.jpg" id="Image4" alt=""></div>
<div id="wb_Form1" style="position:absolute;left:686px;top:299px;width:305px;height:331px;z-index:41;">
<form name="Formverh" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" accept-charset="UTF-8" id="Form1" onsubmit="return ValidateFormverh(this)">
<input type="hidden" name="formid" value="form1">
<input type="text" id="Editbox1" style="position:absolute;left:31px;top:113px;width:231px;height:34px;line-height:34px;z-index:2;" name="Name:" value="" placeholder="&#1042;&#1072;&#1096;&#1077; &#1048;&#1084;&#1103;?">
<input type="text" id="Editbox2" style="position:absolute;left:31px;top:155px;width:231px;height:33px;line-height:33px;z-index:3;" name="Telephone:" value="" placeholder="&#1042;&#1072;&#1096; &#1058;&#1077;&#1083;&#1077;&#1092;&#1086;&#1085;?">
<div id="wb_Text2" style="position:absolute;left:9px;top:24px;width:287px;height:66px;text-align:center;z-index:4;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:19px;"><strong>ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНЫЙ ВЫЕЗД МАСТЕРА И ПОЛУЧИТЕ СКИДКУ ПО АКЦИИ!</strong></span></div>
<input type="submit" id="Button1" name="Knopka" value="Оставить Заявку" style="position:absolute;left:24px;top:208px;width:257px;height:47px;z-index:5;">
<div id="wb_Text8" style="position:absolute;left:44px;top:276px;width:216px;height:32px;text-align:center;z-index:6;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:13px;">В&#1040;&#1064;&#1048; &#1044;&#1040;&#1053;&#1053;&#1067;&#1045; &#1053;&#1045; &#1041;&#1059;&#1044;&#1059;&#1058; &#1055;&#1045;&#1056;&#1045;&#1044;&#1040;&#1053;&#1067; &#1058;&#1056;&#1045;&#1058;&#1048;&#1052; &#1051;&#1048;&#1062;&#1040;&#1052;</span></div>
</form>
</div>
<div id="wb_ClipArt6" style="position:absolute;left:849px;top:812px;width:142px;height:136px;z-index:42;">
<img src="images/img0025.png" id="ClipArt6" alt="" style="width:142px;height:136px;"></div>
<div id="wb_ClipArt4" style="position:absolute;left:646px;top:812px;width:142px;height:136px;z-index:43;">
<img src="images/img0032.png" id="ClipArt4" alt="" style="width:142px;height:136px;"></div>
<div id="wb_ClipArt5" style="position:absolute;left:434px;top:812px;width:142px;height:136px;z-index:44;">
<img src="images/img0033.png" id="ClipArt5" alt="" style="width:142px;height:136px;"></div>
<div id="wb_ClipArt2" style="position:absolute;left:219px;top:812px;width:142px;height:136px;z-index:45;">
<img src="images/img0034.png" id="ClipArt2" alt="" style="width:142px;height:136px;"></div>
<div id="wb_ClipArt3" style="position:absolute;left:7px;top:812px;width:142px;height:136px;z-index:46;">
<img src="images/img0035.png" id="ClipArt3" alt="" style="width:142px;height:136px;"></div>
<div id="wb_Text11" style="position:absolute;left:3px;top:963px;width:149px;height:88px;text-align:center;z-index:47;">
<span style="color:#696969;font-family:Boblic;font-size:19px;"><strong>Срочный выезда всего за 1 час и никаких переплат</strong></span></div>
<div id="wb_Text14" style="position:absolute;left:19px;top:857px;width:116px;height:50px;text-align:center;z-index:48;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:43px;"><strong>1 ЧАС</strong></span></div>
<div id="wb_Text15" style="position:absolute;left:186px;top:963px;width:206px;height:110px;text-align:center;z-index:49;">
<span style="color:#696969;font-family:Boblic;font-size:19px;"><strong>Случаях мастер<br>приедет с необходимой<br>запчастью и выполнит<br>ремонт при первом визите</strong></span></div>
<div id="wb_Text19" style="position:absolute;left:230px;top:848px;width:122px;height:50px;text-align:center;z-index:50;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:43px;"><strong>95%</strong></span></div>
<div id="wb_Text20" style="position:absolute;left:428px;top:861px;width:157px;height:41px;text-align:center;z-index:51;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:35px;"><strong>от 3 лет</strong></span></div>
<div id="wb_Text22" style="position:absolute;left:415px;top:963px;width:180px;height:88px;text-align:center;z-index:52;">
<span style="color:#696969;font-family:Boblic;font-size:19px;"><strong>Гарантия на все<br>работы +<br>постгарантийное<br>обслуживание</strong></span></div>
<div id="wb_Text23" style="position:absolute;left:665px;top:857px;width:105px;height:50px;text-align:center;z-index:53;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:43px;"><strong>750</strong></span></div>
<div id="wb_Text27" style="position:absolute;left:641px;top:963px;width:153px;height:88px;text-align:center;z-index:54;">
<span style="color:#696969;font-family:Boblic;font-size:19px;"><strong>Отремонтировано<br>бытовой техники за год</strong></span></div>
<div id="wb_Text31" style="position:absolute;left:846px;top:857px;width:152px;height:41px;text-align:center;z-index:55;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:35px;"><strong>от 5 лет</strong></span></div>
<div id="wb_Text32" style="position:absolute;left:844px;top:963px;width:153px;height:44px;text-align:center;z-index:56;">
<span style="color:#696969;font-family:Boblic;font-size:19px;"><strong>Опыт работы<br>наших мастеров</strong></span></div>
<div id="wb_Text33" style="position:absolute;left:313px;top:1557px;width:374px;height:56px;text-align:center;z-index:57;">
<span style="color:#000000;font-family:Boblic;font-size:48px;"><strong>НАШИ ГАРАНТИИ</strong></span></div>
<div id="wb_Line20" style="position:absolute;left:181px;top:1714px;width:0px;height:282px;z-index:58;">
<img src="images/img0002.png" id="Line20" alt=""></div>
<div id="wb_Line21" style="position:absolute;left:368px;top:1714px;width:0px;height:282px;z-index:59;">
<img src="images/img0003.png" id="Line21" alt=""></div>
<div id="wb_Line22" style="position:absolute;left:574px;top:1714px;width:0px;height:282px;z-index:60;">
<img src="images/img0004.png" id="Line22" alt=""></div>
<div id="wb_Line23" style="position:absolute;left:790px;top:1714px;width:0px;height:282px;z-index:61;">
<img src="images/img0013.png" id="Line23" alt=""></div>
<div id="wb_Text37" style="position:absolute;left:0px;top:1837px;width:169px;height:140px;text-align:center;z-index:62;">
<span style="color:#696969;font-family:Boblic;font-size:17px;">До 3 лет гарантии на запчасти и работы. Мастера с опытом от 5 лет. Запчасти высокой надежности и длительным сроком службы.</span></div>
<div id="wb_Text38" style="position:absolute;left:36px;top:1789px;width:113px;height:28px;text-align:center;z-index:63;">
<span style="color:#696969;font-family:Boblic;font-size:24px;"><strong>КАЧЕСТВО</strong></span><span style="color:#696969;font-family:Boblic;font-size:17px;"><strong> </strong></span></div>
<div id="wb_Text39" style="position:absolute;left:188px;top:1837px;width:181px;height:100px;text-align:center;z-index:64;">
<span style="color:#696969;font-family:Boblic;font-size:17px;">После диагностики вам скажут, стоит ли заменить те или иные запчасти или же лучше сразу купить новую технику.</span></div>
<div id="wb_Text51" style="position:absolute;left:223px;top:1789px;width:113px;height:28px;text-align:center;z-index:65;">
<span style="color:#696969;font-family:Boblic;font-size:24px;"><strong>ЧЕСТНОСТЬ </strong></span></div>
<div id="wb_Text53" style="position:absolute;left:384px;top:1837px;width:181px;height:120px;text-align:center;z-index:66;">
<span style="color:#696969;font-family:Boblic;font-size:17px;">Наши мастера уберут всю грязь, а также старые детали после ремонта. Так что Вам не придется после мастера приводить все в порядок.</span></div>
<div id="wb_Text54" style="position:absolute;left:416px;top:1789px;width:113px;height:28px;text-align:center;z-index:67;">
<span style="color:#696969;font-family:Boblic;font-size:24px;"><strong>Чистота</strong></span></div>
<div id="wb_Text55" style="position:absolute;left:584px;top:1837px;width:203px;height:120px;text-align:center;z-index:68;">
<span style="color:#696969;font-family:Boblic;font-size:17px;">Собственная служба логистики обеспечивает приезд мастера точно в срок. В нашем сервисе более 30 квалифицированных мастеров.</span></div>
<div id="wb_Text56" style="position:absolute;left:632px;top:1789px;width:113px;height:28px;text-align:center;z-index:69;">
<span style="color:#696969;font-family:Boblic;font-size:24px;"><strong>Сроки</strong></span></div>
<div id="wb_Text57" style="position:absolute;left:802px;top:1837px;width:181px;height:140px;text-align:center;z-index:70;">
<span style="color:#696969;font-family:Boblic;font-size:17px;">После проведения работ, вы получаете бланк строгой отчетности БСО-1, на основании которого можете обратиться к нам, в случае возникновения гарантийного случая.</span></div>
<div id="wb_Text58" style="position:absolute;left:818px;top:1789px;width:166px;height:28px;text-align:center;z-index:71;">
<span style="color:#696969;font-family:Boblic;font-size:24px;"><strong>Документация</strong></span></div>
<div id="wb_Text77" style="position:absolute;left:311px;top:2039px;width:378px;height:56px;text-align:center;z-index:72;">
<span style="color:#000000;font-family:Boblic;font-size:48px;"><strong>КАК МЫ РАБОТАЕМ</strong></span></div>
<div id="wb_Image29" style="position:absolute;left:187px;top:2161px;width:39px;height:42px;z-index:73;">
<img src="images/sep-label.png" id="Image29" alt=""></div>
<div id="wb_Image37" style="position:absolute;left:384px;top:2161px;width:39px;height:42px;z-index:74;">
<img src="images/sep-label.png" id="Image37" alt=""></div>
<div id="wb_Image38" style="position:absolute;left:572px;top:2161px;width:39px;height:42px;z-index:75;">
<img src="images/sep-label.png" id="Image38" alt=""></div>
<div id="wb_Image39" style="position:absolute;left:754px;top:2161px;width:39px;height:42px;z-index:76;">
<img src="images/sep-label.png" id="Image39" alt=""></div>
<div id="wb_Text41" style="position:absolute;left:59px;top:2280px;width:127px;height:72px;text-align:center;z-index:77;">
<span style="color:#696969;font-family:Boblic;font-size:16px;">Вы делаете заказ<br>по телефону или<br>онлайн через наш сайт.</span></div>
<div id="wb_Text43" style="position:absolute;left:83px;top:2235px;width:77px;height:24px;text-align:center;z-index:78;">
<span style="color:#696969;font-family:Boblic;font-size:20px;"><strong>ЗАКАЗ</strong></span><span style="color:#696969;font-family:Boblic;font-size:17px;"><strong> </strong></span></div>
<div id="wb_Text44" style="position:absolute;left:236px;top:2280px;width:137px;height:54px;text-align:center;z-index:79;">
<span style="color:#696969;font-family:Boblic;font-size:16px;">Мастер приезжает к<br>Вам и производит<br>диагностику.</span></div>
<div id="wb_Text46" style="position:absolute;left:236px;top:2235px;width:137px;height:24px;text-align:center;z-index:80;">
<span style="color:#696969;font-family:Boblic;font-size:20px;"><strong>ДИАГНОСТИКА</strong></span><span style="color:#696969;font-family:Boblic;font-size:17px;"><strong> </strong></span></div>
<div id="wb_Text62" style="position:absolute;left:421px;top:2280px;width:151px;height:72px;text-align:center;z-index:81;">
<span style="color:#696969;font-family:Boblic;font-size:16px;">Если Вас устраивает<br>стоимость услуг,<br>мы приступаем к работам.</span></div>
<div id="wb_Text70" style="position:absolute;left:428px;top:2235px;width:137px;height:24px;text-align:center;z-index:82;">
<span style="color:#696969;font-family:Boblic;font-size:20px;"><strong>СТОИМОСТЬ</strong></span><span style="color:#696969;font-family:Boblic;font-size:17px;"><strong> </strong></span></div>
<div id="wb_Text71" style="position:absolute;left:619px;top:2283px;width:137px;height:54px;text-align:center;z-index:83;">
<span style="color:#696969;font-family:Boblic;font-size:16px;">Мастер приезжает к<br>Вам и производит<br>диагностику.</span></div>
<div id="wb_Text72" style="position:absolute;left:586px;top:2235px;width:195px;height:24px;text-align:center;z-index:84;">
<span style="color:#696969;font-family:Boblic;font-size:20px;"><strong>ИСПРАВНАЯ ТЕХНИКА</strong></span></div>
<div id="wb_Text73" style="position:absolute;left:806px;top:2280px;width:137px;height:54px;text-align:center;z-index:85;">
<span style="color:#696969;font-family:Boblic;font-size:16px;">Мастер приезжает к<br>Вам и производит<br>диагностику.</span></div>
<div id="wb_Text74" style="position:absolute;left:806px;top:2235px;width:137px;height:24px;text-align:center;z-index:86;">
<span style="color:#696969;font-family:Boblic;font-size:20px;"><strong>ДИАГНОСТИКА</strong></span><span style="color:#696969;font-family:Boblic;font-size:17px;"><strong> </strong></span></div>
<div id="wb_Image24" style="position:absolute;left:103px;top:2966px;width:515px;height:695px;z-index:87;">
<img src="images/OI.jpg" id="Image24" alt=""></div>
<div id="wb_Text79" style="position:absolute;left:446px;top:2981px;width:349px;height:60px;z-index:88;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">Цены ниже рыночных по сравнению с другими компаниями на 30%, за счёт собственного склада запчастей</span></div>
<div id="wb_Text80" style="position:absolute;left:536px;top:3071px;width:351px;height:60px;z-index:89;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">Мы даем гарантию, что специалисты прибудут на объект в оговоренное время или же проведут работы со скидкой</span></div>
<div id="wb_Text81" style="position:absolute;left:586px;top:3167px;width:311px;height:60px;z-index:90;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">Мы устанавливаем запчасти только высокой надежности и длительным сроком службы. Что позволяет давать гарантию до 3-х лет</span></div>
<div id="wb_Text82" style="position:absolute;left:614px;top:3283px;width:273px;height:60px;z-index:91;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">Квалифицированные специалисты с опытом более 5 лет, прошедшие полную аттестацию</span></div>
<div id="wb_Text83" style="position:absolute;left:586px;top:3395px;width:304px;height:60px;z-index:92;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">Наши мастера и менеджеры бесплатно проконсультируют и дадут рекомендации по использованию бытовой техники</span></div>
<div id="wb_Text84" style="position:absolute;left:537px;top:3495px;width:273px;height:80px;z-index:93;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">Скидки для пенсионеров и инвалидов. скидка при повторном обращении, приятные бонусы постоянным клиентам</span></div>
<div id="wb_Text85" style="position:absolute;left:449px;top:3600px;width:353px;height:60px;z-index:94;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:17px;">У наших мастеров профессиональные инструменты это напрямую влияет на скорость работ, качество и долговечность работы оборудования</span></div>
<div id="wb_Text1" style="position:absolute;left:124px;top:3714px;width:753px;height:56px;text-align:center;z-index:95;">
<span style="color:#000000;font-family:Boblic;font-size:48px;"><strong>РЕМОНТИРУЕМ И УСТАНАВЛИВАЕМ</strong></span></div>
<div id="wb_Text4" style="position:absolute;left:71px;top:4023px;width:188px;height:22px;text-align:center;z-index:96;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">СТИРАЛЬНЫЕ МАШИНЫ </span></div>
<div id="wb_Text5" style="position:absolute;left:290px;top:4023px;width:182px;height:22px;text-align:center;z-index:97;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">СУШИЛЬНЫЕ МАШИНЫ </span></div>
<div id="wb_Text6" style="position:absolute;left:496px;top:4023px;width:217px;height:22px;text-align:center;z-index:98;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">ПОСУДОМОЕЧНЫЕ МАШИНЫ </span></div>
<div id="wb_Text7" style="position:absolute;left:745px;top:4023px;width:158px;height:22px;text-align:center;z-index:99;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">ХОЛОДИЛЬНИКИ </span></div>
<div id="wb_Text10" style="position:absolute;left:86px;top:4285px;width:157px;height:22px;text-align:center;z-index:100;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">КОНДИЦИОНЕРЫ </span></div>
<div id="wb_Text12" style="position:absolute;left:281px;top:4285px;width:204px;height:22px;text-align:center;z-index:101;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">ГАЗОВЫЕ И ЭЛЕКТРОПЛИТЫ </span></div>
<div id="wb_Text24" style="position:absolute;left:517px;top:4285px;width:179px;height:22px;text-align:center;z-index:102;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">ВАРОЧНЫЕ ПАНЕЛИ </span></div>
<div id="wb_Text25" style="position:absolute;left:747px;top:4285px;width:159px;height:22px;text-align:center;z-index:103;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">ДУХОВЫЕ ШКАФЫ</span></div>
<div id="wb_Text61" style="position:absolute;left:197px;top:4363px;width:601px;height:56px;text-align:center;z-index:104;">
<span style="color:#000000;font-family:Boblic;font-size:48px;"><strong>ОТЗЫВЫ НАШИХ КЛИЕНТОВ</strong></span></div>
<div id="wb_Image28" style="position:absolute;left:242px;top:4474px;width:125px;height:125px;z-index:105;">
<img src="images/d09a1-n1%5B1%5D.jpg" id="Image28" alt=""></div>
<div id="wb_Text64" style="position:absolute;left:51px;top:4619px;width:360px;height:110px;z-index:106;text-align:left;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">Здравствуйте хочу поблагодарить мастера по имени Алексей, который ремонтировал мою стиральную машину &quot;Bosh&quot;, которая перестала греть воду. Буду рекомендовать ваш сервис друзьям. </span></div>
<div id="wb_Line6" style="position:absolute;left:49px;top:4603px;width:363px;height:0px;z-index:107;">
<img src="images/img0011.png" id="Line6" alt=""></div>
<div id="wb_Text65" style="position:absolute;left:77px;top:4566px;width:125px;height:41px;z-index:108;text-align:left;">
<span style="color:#F14F00;font-family:Boblic;font-size:35px;">Марина</span></div>
<div id="wb_Text86" style="position:absolute;left:51px;top:4919px;width:360px;height:88px;z-index:109;text-align:left;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">Часто сомневаюсь, когда говорят, что мастер приедет в течение часа. В случае с вашим сервисом сомнения отпали! Мастер приехал и починил быстро и качественно!</span></div>
<div id="wb_Line25" style="position:absolute;left:50px;top:4903px;width:363px;height:0px;z-index:110;">
<img src="images/img0012.png" id="Line25" alt=""></div>
<div id="wb_Text87" style="position:absolute;left:77px;top:4866px;width:125px;height:41px;z-index:111;text-align:left;">
<span style="color:#F14F00;font-family:Boblic;font-size:35px;">Алла</span></div>
<div id="wb_Image30" style="position:absolute;left:242px;top:4773px;width:125px;height:125px;z-index:112;">
<img src="images/a20aa-n5%5B1%5D.jpg" id="Image30" alt=""></div>
<div id="wb_Text88" style="position:absolute;left:577px;top:4619px;width:360px;height:88px;z-index:113;text-align:left;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">Никогда не оставлял отзывы. Но решил, что уж очень хочется, чтоб другие тоже знали. Бесплатный выезд мастера и проделанная работа за 30 минут говорят сами за себя!</span></div>
<div id="wb_Line26" style="position:absolute;left:575px;top:4603px;width:363px;height:0px;z-index:114;">
<img src="images/img0014.png" id="Line26" alt=""></div>
<div id="wb_Text89" style="position:absolute;left:579px;top:4566px;width:125px;height:82px;z-index:115;text-align:left;">
<span style="color:#F14F00;font-family:Boblic;font-size:35px;">Дмитрий</span></div>
<div id="wb_Image31" style="position:absolute;left:753px;top:4474px;width:125px;height:125px;z-index:116;">
<img src="images/91d71-n2%5B1%5D.jpg" id="Image31" alt=""></div>
<div id="wb_Text90" style="position:absolute;left:579px;top:4919px;width:360px;height:66px;z-index:117;text-align:left;">
<span style="color:#696969;font-family:Boblic;font-size:19px;">Подруга посоветовала обратиться в ваш сервис. Результатом довольна. Теперь сама буду советовать Ваш сервис.</span></div>
<div id="wb_Line27" style="position:absolute;left:577px;top:4903px;width:363px;height:0px;z-index:118;">
<img src="images/img0016.png" id="Line27" alt=""></div>
<div id="wb_Text91" style="position:absolute;left:581px;top:4866px;width:136px;height:41px;z-index:119;text-align:left;">
<span style="color:#F14F00;font-family:Boblic;font-size:35px;">Кристина</span></div>
<div id="wb_Image32" style="position:absolute;left:753px;top:4773px;width:125px;height:125px;z-index:120;">
<img src="images/821bf-n3%5B1%5D.jpg" id="Image32" alt=""></div>
<div id="wb_Image3" style="position:absolute;left:93px;top:2155px;width:60px;height:63px;z-index:121;">
<img src="images/r1.png" id="Image3" alt=""></div>
<div id="wb_Image22" style="position:absolute;left:274px;top:2150px;width:60px;height:63px;z-index:122;">
<img src="images/r2.png" id="Image22" alt=""></div>
<div id="wb_Image23" style="position:absolute;left:465px;top:2150px;width:60px;height:63px;z-index:123;">
<img src="images/r3.png" id="Image23" alt=""></div>
<div id="wb_Image25" style="position:absolute;left:649px;top:2150px;width:60px;height:63px;z-index:124;">
<img src="images/r4.png" id="Image25" alt=""></div>
<div id="wb_Image26" style="position:absolute;left:843px;top:2150px;width:60px;height:63px;z-index:125;">
<img src="images/r5.png" id="Image26" alt=""></div>
<div id="wb_Image33" style="position:absolute;left:32px;top:1659px;width:118px;height:118px;z-index:126;">
<img src="images/w1.png" id="Image33" alt=""></div>
<div id="wb_Image2" style="position:absolute;left:220px;top:1659px;width:118px;height:118px;z-index:127;">
<img src="images/w2.png" id="Image2" alt=""></div>
<div id="wb_Image14" style="position:absolute;left:414px;top:1658px;width:118px;height:118px;z-index:128;">
<img src="images/w3.png" id="Image14" alt=""></div>
<div id="wb_Image15" style="position:absolute;left:629px;top:1659px;width:118px;height:118px;z-index:129;">
<img src="images/w4.png" id="Image15" alt=""></div>
<div id="wb_Image17" style="position:absolute;left:845px;top:1658px;width:118px;height:118px;z-index:130;">
<img src="images/w5.png" id="Image17" alt=""></div>
<div id="wb_Image19" style="position:absolute;left:0px;top:5471px;width:185px;height:47px;z-index:131;">
<a href="http://landing.webnow.uz/" target="_blank"><img src="images/sozdanie-prodvizhenie-sajtov-tashkent.png" id="Image19" alt=""></a></div>
<div id="wb_Text92" style="position:absolute;left:192px;top:5470px;width:678px;height:50px;z-index:132;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:48px;"><strong>НАШИ УСЛУГИ ПО РЕМОТУ ДОСТУПНЫ ВСЕМ</strong></span></div>
<div id="wb_Shape1" style="position:absolute;left:419px;top:1224px;width:587px;height:249px;filter:alpha(opacity=80);-moz-opacity:0.80;opacity:0.80;z-index:134;">
<img src="images/img0001.png" id="Shape1" alt="" style="width:587px;height:249px;"></div>
<div id="wb_Text16" style="position:absolute;left:552px;top:1247px;width:443px;height:192px;z-index:135;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:27px;">- Загрязнение фильтров кондиционера;<br>- Неисправность дренажной системы;<br>- Загрязнение радиатора конденсатора;<br>- Неисправность терморезисторов;<br>- Короткое замыкание компрессора;<br>- Неполадки пульта управления.</span></div>
<div id="wb_Image5" style="position:absolute;left:639px;top:533px;width:92px;height:85px;z-index:136;">
<img src="images/arrow.png" id="Image5" alt=""></div>
<div id="wb_Image7" style="position:absolute;left:0px;top:1223px;width:400px;height:215px;z-index:137;">
<img src="images/iiiiiiiiiiiiiiiiiiiiiii.jpg" id="Image7" alt=""></div>
<div id="wb_Shape4" style="position:absolute;left:77px;top:1466px;width:256px;height:63px;z-index:138;">
<a href="javascript:displaylightbox('./zayavka.php',{width:317,height:304})" target="_self"><img class="hover" src="images/img0005_hover.png" alt="" style="border-width:0;width:256px;height:63px;"><span><img src="images/img0005.png" id="Shape4" alt="" style="width:256px;height:63px;"></span></a></div>
</div>
<div id="Layer3" style="position:absolute;text-align:center;left:0px;top:0px;width:100%;height:126px;z-index:139;">
<div id="Layer3_Container" style="width:1000px;position:relative;margin-left:auto;margin-right:auto;text-align:left;">
<div id="wb_Text3" style="position:absolute;left:727px;top:9px;width:264px;height:102px;text-align:right;z-index:0;">
<span style="color:#FF0000;font-family:Arial;font-size:29px;"><strong>Звоните нам!</strong></span><span style="background-color:#F5F5F5;color:#FF0000;font-family:Arial;font-size:29px;"><strong><br></strong></span><span style="color:#1E90FF;font-family:Arial;font-size:29px;"><strong>+7-495-128-08-98<br>+7-925-567-53-77</strong></span></div>
<div id="wb_Text9" style="position:absolute;left:0px;top:15px;width:747px;height:82px;z-index:1;text-align:left;">
<span style="color:#FF0000;font-family:Boblic;font-size:35px;"><strong>РЕМОНТ ОБСЛУЖИВАНИЕ КОНДИЦИОНЕРА В МОСКВЕ </strong></span><span style="color:#2FA8BD;font-family:Boblic;font-size:37px;"><strong><br></strong></span><span style="background-color:#1E90FF;color:#FFFFFF;font-family:Boblic;font-size:35px;"><strong>ЛЮБОЙ СЛОЖНОСТИ | АБСОЛЮТНО ВСЕХ БРЕНДОВ</strong></span></div>
</div>
</div>
<div id="Layer1" style="position:absolute;text-align:center;left:0px;top:2382px;width:100%;height:561px;z-index:140;">
<div id="Layer1_Container" style="width:1000px;position:relative;margin-left:auto;margin-right:auto;text-align:left;">
<div id="wb_Image16" style="position:absolute;left:241px;top:126px;width:213px;height:213px;z-index:12;">
<img src="images/k1.png" id="Image16" alt=""></div>
<div id="wb_Image21" style="position:absolute;left:25px;top:42px;width:262px;height:262px;z-index:13;">
<img src="images/k1.png" id="Image21" alt=""></div>
<div id="wb_Text49" style="position:absolute;left:79px;top:76px;width:166px;height:62px;text-align:justify;z-index:14;">
<span style="color:#00BFFF;font-family:Boblic;font-size:53px;"><strong>АКЦИЯ!</strong></span></div>
<div id="wb_Text60" style="position:absolute;left:49px;top:152px;width:210px;height:114px;text-align:center;z-index:15;">
<span style="color:#696969;font-family:Boblic;font-size:32px;"><strong>только сегодня к каждой заявке</strong></span></div>
<div id="wb_Text75" style="position:absolute;left:310px;top:150px;width:85px;height:62px;text-align:justify;z-index:16;">
<span style="color:#FFA500;font-family:Boblic;font-size:53px;"><strong>20%</strong></span></div>
<div id="wb_Text76" style="position:absolute;left:244px;top:212px;width:210px;height:96px;text-align:center;z-index:17;">
<span style="color:#696969;font-family:Boblic;font-size:27px;"><strong>скидка <br>на все услуги + подарок</strong></span></div>
<div id="wb_Shape2" style="position:absolute;left:7px;top:370px;width:485px;height:144px;filter:alpha(opacity=70);-moz-opacity:0.70;opacity:0.70;z-index:18;">
<img src="images/img0007.png" id="Shape2" alt="" style="width:485px;height:144px;"></div>
<div id="wb_Text78" style="position:absolute;left:21px;top:415px;width:449px;height:64px;text-align:center;z-index:19;">
<span style="color:#000000;font-family:Boblic;font-size:27px;"><strong>РЕМОНТИРУЕМ АБСОЛЮТНО ВСЕ БРЕНДЫ И МОДЕЛИ!</strong></span></div>
<div id="wb_Form2" style="position:absolute;left:665px;top:126px;width:305px;height:331px;z-index:20;">
<form name="Formseredina" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" accept-charset="UTF-8" id="Form2" onsubmit="return ValidateFormseredina(this)">
<input type="hidden" name="formid" value="form2">
<input type="text" id="Editbox3" style="position:absolute;left:31px;top:119px;width:231px;height:34px;line-height:34px;z-index:7;" name="Name:" value="" placeholder="&#1042;&#1072;&#1096;&#1077; &#1048;&#1084;&#1103;?">
<input type="text" id="Editbox4" style="position:absolute;left:31px;top:161px;width:231px;height:33px;line-height:33px;z-index:8;" name="Telephone:" value="" placeholder="&#1042;&#1072;&#1096; &#1058;&#1077;&#1083;&#1077;&#1092;&#1086;&#1085;?">
<div id="wb_Text30" style="position:absolute;left:9px;top:31px;width:287px;height:66px;text-align:center;z-index:9;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:19px;"><strong>ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНЫЙ ВЫЕЗД МАСТЕРА И ПОЛУЧИТЕ СКИДКУ ПО АКЦИИ!</strong></span></div>
<input type="submit" id="Button2" name="Knopka" value="Оставить Заявку" style="position:absolute;left:24px;top:216px;width:257px;height:47px;z-index:10;">
<div id="wb_Text17" style="position:absolute;left:44px;top:283px;width:216px;height:32px;text-align:center;z-index:11;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:13px;">В&#1040;&#1064;&#1048; &#1044;&#1040;&#1053;&#1053;&#1067;&#1045; &#1053;&#1045; &#1041;&#1059;&#1044;&#1059;&#1058; &#1055;&#1045;&#1056;&#1045;&#1044;&#1040;&#1053;&#1067; &#1058;&#1056;&#1045;&#1058;&#1048;&#1052; &#1051;&#1048;&#1062;&#1040;&#1052;</span></div>
</form>
</div>
<div id="wb_Image1" style="position:absolute;left:618px;top:357px;width:92px;height:85px;z-index:21;">
<img src="images/arrow.png" id="Image1" alt=""></div>
<!-- RedConnect -->
<script id="rhlpscrtg" type="text/javascript" charset="utf-8" async="async"
src="https://web.redhelper.ru/service/main.js?c=agentsw"></script>
<div style="display: none"><a class="rc-copyright" 
href="http://redconnect.ru">Сервис обратного звонка RedConnect</a></div>
<!--/RedConnect -->
</div>
</div>
<div id="Layer2" style="position:absolute;text-align:center;left:0px;top:5028px;width:100%;height:437px;z-index:141;">
<div id="Layer2_Container" style="width:1000px;position:relative;margin-left:auto;margin-right:auto;text-align:left;">
<div id="wb_Image27" style="position:absolute;left:508px;top:55px;width:491px;height:351px;z-index:27;">
<img src="images/form_bg.png" id="Image27" alt=""></div>
<div id="wb_Text59" style="position:absolute;left:16px;top:71px;width:492px;height:112px;text-align:center;z-index:28;">
<span style="color:#000000;font-family:Boblic;font-size:48px;"><strong>ОСТАЛИСЬ ВОПРОСЫ? ЗВОНИТЕ!</strong></span></div>
<div id="wb_Form3" style="position:absolute;left:545px;top:71px;width:416px;height:302px;z-index:29;">
<form name="Formniz" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" accept-charset="UTF-8" id="Form3" onsubmit="return ValidateFormniz(this)">
<input type="hidden" name="formid" value="form3">
<input type="text" id="Editbox5" style="position:absolute;left:70px;top:102px;width:264px;height:34px;line-height:34px;z-index:22;" name="Name:" value="" placeholder="&#1042;&#1072;&#1096;&#1077; &#1048;&#1084;&#1103;?">
<input type="text" id="Editbox6" style="position:absolute;left:70px;top:147px;width:264px;height:34px;line-height:34px;z-index:23;" name="Telephone:" value="" placeholder="&#1042;&#1072;&#1096; &#1058;&#1077;&#1083;&#1077;&#1092;&#1086;&#1085;?">
<div id="wb_Text26" style="position:absolute;left:74px;top:276px;width:268px;height:16px;text-align:center;z-index:24;">
<span style="color:#FF0000;font-family:Boblic;font-size:13px;">В&#1040;&#1064;&#1048; &#1044;&#1040;&#1053;&#1053;&#1067;&#1045; &#1053;&#1045; &#1041;&#1059;&#1044;&#1059;&#1058; &#1055;&#1045;&#1056;&#1045;&#1044;&#1040;&#1053;&#1067; &#1058;&#1056;&#1045;&#1058;&#1048;&#1052; &#1051;&#1048;&#1062;&#1040;&#1052;</span></div>
<div id="wb_Text48" style="position:absolute;left:53px;top:16px;width:310px;height:66px;text-align:center;z-index:25;">
<span style="color:#FF0000;font-family:Boblic;font-size:19px;"><strong>ОСТАВЬТЕ ЗАЯВКУ НА БЕСПЛАТНЫЙ ВЫЕЗД МАСТЕРА И ПОЛУЧИТЕ <br>СКИДКУ ПО АКЦИИ!</strong></span></div>
<input type="submit" id="Button3" name="Knopka" value="Оставить Заявку" style="position:absolute;left:70px;top:202px;width:276px;height:47px;z-index:26;">
</form>
</div>
</div>
</div>
</body>
</html>