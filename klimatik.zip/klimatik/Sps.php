<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Ремонт | Установка кондиционеров в Ташкенте по доступным ценам</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="Kondicioner.css" rel="stylesheet" type="text/css">
<link href="Sps.css" rel="stylesheet" type="text/css">
<!-- Поместите код Google Analystics сюда -->
</head>
<body>
<div id="container">
<div id="wb_Text2" style="position:absolute;left:14px;top:102px;width:287px;height:96px;text-align:center;z-index:0;">
<span style="color:#FFFFFF;font-family:Boblic;font-size:27px;"><strong>Спасибо за вашу заявку!<br>Мы скоро с вами свяжемся!</strong></span></div>
</div>
</body>
</html>