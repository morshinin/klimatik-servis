<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Ремонт | Установка кондиционеров в Ташкенте по доступным ценам</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="Kondicioner.css" rel="stylesheet" type="text/css">
<link href="spasibo.css" rel="stylesheet" type="text/css">
<!-- Поместите код Google Analystics сюда -->
</head>
<body>
<div id="container">
<a href="http://www.wysiwygwebbuilder.com" target="_blank"><img src="images/builtwithwwb10.png" alt="WYSIWYG Web Builder" style="position:absolute;left:456px;top:805px;border-width:0;z-index:250"></a>
<div id="wb_Text2" style="position:absolute;left:40px;top:221px;width:921px;height:225px;text-align:center;z-index:1;">
<span style="color:#FF6347;font-family:Boblic;font-size:64px;"><strong>СПАСИБО ЗА ВАШУ ЗАЯВКУ<br>МЫ СВЯЖЕМСЯ С ВАМИ В БЛИЖАЙШЕЕ ВРЕМЯ!</strong></span></div>
<div id="wb_ClipArt1" style="position:absolute;left:646px;top:29px;width:48px;height:36px;z-index:2;">
<img src="images/img0018.png" id="ClipArt1" alt="" style="width:48px;height:36px;"></div>
<div id="wb_Text3" style="position:absolute;left:700px;top:25px;width:287px;height:43px;z-index:3;text-align:left;">
<span style="color:#000000;font-family:Boblic;font-size:37px;"><strong>(99871) 255-14-57</strong></span></div>
<div id="wb_Text1" style="position:absolute;left:301px;top:676px;width:399px;height:41px;text-align:center;z-index:4;">
<span style="color:#000000;font-family:Boblic;font-size:35px;"><strong><a href="./index.php">ВЕРНУТЬСЯ НА СТРАНИЦУ</a></strong></span></div>
</div>
<div id="Layer2" style="position:absolute;text-align:left;left:1px;top:610px;width:99%;height:42px;z-index:5;">
</div>
</body>
</html>